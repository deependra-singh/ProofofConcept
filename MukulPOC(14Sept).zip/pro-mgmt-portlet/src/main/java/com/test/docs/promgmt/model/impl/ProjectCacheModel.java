package com.test.docs.promgmt.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.test.docs.promgmt.model.Project;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Project in entity cache.
 *
 * @author mukulkul
 * @see Project
 * @generated
 */
public class ProjectCacheModel implements CacheModel<Project>, Externalizable {
    public String uuid;
    public long projectId;
    public long groupId;
    public long companyId;
    public long userId;
    public String userName;
    public long createDate;
    public long modifiedDate;
    public String proTitle;
    public String description;
    public long imageId;
    public int status;
    public long statusByUserId;
    public String statusByUserName;
    public long statusDate;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(31);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", projectId=");
        sb.append(projectId);
        sb.append(", groupId=");
        sb.append(groupId);
        sb.append(", companyId=");
        sb.append(companyId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append(", userName=");
        sb.append(userName);
        sb.append(", createDate=");
        sb.append(createDate);
        sb.append(", modifiedDate=");
        sb.append(modifiedDate);
        sb.append(", proTitle=");
        sb.append(proTitle);
        sb.append(", description=");
        sb.append(description);
        sb.append(", imageId=");
        sb.append(imageId);
        sb.append(", status=");
        sb.append(status);
        sb.append(", statusByUserId=");
        sb.append(statusByUserId);
        sb.append(", statusByUserName=");
        sb.append(statusByUserName);
        sb.append(", statusDate=");
        sb.append(statusDate);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Project toEntityModel() {
        ProjectImpl projectImpl = new ProjectImpl();

        if (uuid == null) {
            projectImpl.setUuid(StringPool.BLANK);
        } else {
            projectImpl.setUuid(uuid);
        }

        projectImpl.setProjectId(projectId);
        projectImpl.setGroupId(groupId);
        projectImpl.setCompanyId(companyId);
        projectImpl.setUserId(userId);

        if (userName == null) {
            projectImpl.setUserName(StringPool.BLANK);
        } else {
            projectImpl.setUserName(userName);
        }

        if (createDate == Long.MIN_VALUE) {
            projectImpl.setCreateDate(null);
        } else {
            projectImpl.setCreateDate(new Date(createDate));
        }

        if (modifiedDate == Long.MIN_VALUE) {
            projectImpl.setModifiedDate(null);
        } else {
            projectImpl.setModifiedDate(new Date(modifiedDate));
        }

        if (proTitle == null) {
            projectImpl.setProTitle(StringPool.BLANK);
        } else {
            projectImpl.setProTitle(proTitle);
        }

        if (description == null) {
            projectImpl.setDescription(StringPool.BLANK);
        } else {
            projectImpl.setDescription(description);
        }

        projectImpl.setImageId(imageId);
        projectImpl.setStatus(status);
        projectImpl.setStatusByUserId(statusByUserId);

        if (statusByUserName == null) {
            projectImpl.setStatusByUserName(StringPool.BLANK);
        } else {
            projectImpl.setStatusByUserName(statusByUserName);
        }

        if (statusDate == Long.MIN_VALUE) {
            projectImpl.setStatusDate(null);
        } else {
            projectImpl.setStatusDate(new Date(statusDate));
        }

        projectImpl.resetOriginalValues();

        return projectImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        projectId = objectInput.readLong();
        groupId = objectInput.readLong();
        companyId = objectInput.readLong();
        userId = objectInput.readLong();
        userName = objectInput.readUTF();
        createDate = objectInput.readLong();
        modifiedDate = objectInput.readLong();
        proTitle = objectInput.readUTF();
        description = objectInput.readUTF();
        imageId = objectInput.readLong();
        status = objectInput.readInt();
        statusByUserId = objectInput.readLong();
        statusByUserName = objectInput.readUTF();
        statusDate = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(projectId);
        objectOutput.writeLong(groupId);
        objectOutput.writeLong(companyId);
        objectOutput.writeLong(userId);

        if (userName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(userName);
        }

        objectOutput.writeLong(createDate);
        objectOutput.writeLong(modifiedDate);

        if (proTitle == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(proTitle);
        }

        if (description == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(description);
        }

        objectOutput.writeLong(imageId);
        objectOutput.writeInt(status);
        objectOutput.writeLong(statusByUserId);

        if (statusByUserName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(statusByUserName);
        }

        objectOutput.writeLong(statusDate);
    }
}
