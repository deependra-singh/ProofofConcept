package com.test.docs.promgmt.service.messaging;

import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.Message;

import com.test.docs.promgmt.service.ClpSerializer;
import com.test.docs.promgmt.service.ProjectLocalServiceUtil;
import com.test.docs.promgmt.service.ProjectServiceUtil;


public class ClpMessageListener extends BaseMessageListener {
    public static String getServletContextName() {
        return ClpSerializer.getServletContextName();
    }

    @Override
    protected void doReceive(Message message) throws Exception {
        String command = message.getString("command");
        String servletContextName = message.getString("servletContextName");

        if (command.equals("undeploy") &&
                servletContextName.equals(getServletContextName())) {
            ProjectLocalServiceUtil.clearService();

            ProjectServiceUtil.clearService();
        }
    }
}
