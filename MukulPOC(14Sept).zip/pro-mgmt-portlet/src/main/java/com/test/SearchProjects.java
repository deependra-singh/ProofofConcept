package com.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.servlet.http.HttpServletRequest;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.search.BooleanClauseOccur;
import com.liferay.portal.kernel.search.BooleanQuery;
import com.liferay.portal.kernel.search.BooleanQueryFactoryUtil;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.kernel.search.Hits;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.SearchEngineUtil;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.TermQuery;
import com.liferay.portal.kernel.search.TermQueryFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.util.PortalUtil;
import com.test.docs.promgmt.dto.ProjectSearch;
import com.test.docs.promgmt.model.Project;

public class SearchProjects 
{
	ProjectUploadDownloadImage p1 = new ProjectUploadDownloadImage();
	
	public void viewBySearch(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		String textBox=null;
		textBox = ParamUtil.getString(request, "searchTextbox");
		HttpServletRequest hrequest = PortalUtil.getHttpServletRequest(request);
		SearchContext searchContext = SearchContextFactory.getInstance(PortalUtil.getHttpServletRequest(request));
        
        if(textBox!=null && !textBox.isEmpty())
        {
        	  BooleanQuery fullQuery = BooleanQueryFactoryUtil.create(searchContext);
              BooleanQuery classNameQuery = BooleanQueryFactoryUtil.create(searchContext);
              BooleanQuery searchQuery = BooleanQueryFactoryUtil.create(searchContext);
              
              classNameQuery.addRequiredTerm(Field.ENTRY_CLASS_NAME, Project.class.getName());
              
              searchQuery.addTerm(Field.ASSET_TAG_NAMES, textBox);
              searchQuery.addTerm(Field.TITLE, textBox);
              searchQuery.addTerm(Field.ASSET_CATEGORY_TITLES, textBox);
              
              fullQuery.add(classNameQuery, BooleanClauseOccur.MUST);
              fullQuery.add(searchQuery, BooleanClauseOccur.MUST);
              
              Hits hits = SearchEngineUtil.search(searchContext, fullQuery);
              
              List<ProjectSearch> psList = new ArrayList<ProjectSearch>();
      		
      		for(int i=0;i<hits.getDocs().length;i++)
      		{
      			Document doc = hits.doc(i);
      			
      			String title = doc.get("title");
      			String categoryTitle = doc.get("assetCategoryTitles");
      			String desc = doc.get("description");
      			Long imageId= Long.parseLong(doc.get("content"));
      			Long proId = Long.parseLong(doc.get("classPK"));
      			
      			ProjectSearch ps = new ProjectSearch(proId, title, desc, categoryTitle, imageId);
      			psList.add(ps);
      		}
      		
      		hrequest.setAttribute("projects2", psList);      		
      		p1.urlMap(request, response);
      		
      		response.setRenderParameter("jspPage","/html/projectscategory/showProjectsByCategory.jsp");
        }        
        else
        {
        	System.out.println("Something Went Wrong....");
        }		
	}
	
	public void viewByCategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		long categoryId=0;
		categoryId = ParamUtil.getLong(request, "categoryId");
		String textBox=null;
		textBox = ParamUtil.getString(request, "searchTextbox");
		
		HttpServletRequest hrequest = PortalUtil.getHttpServletRequest(request);
		SearchContext searchContext = SearchContextFactory.getInstance(PortalUtil.getHttpServletRequest(request));
        String searchEngineId = searchContext.getSearchEngineId();
        Long companyId = searchContext.getCompanyId();

        BooleanQuery booleanQuery = BooleanQueryFactoryUtil.create(searchContext);

        TermQuery termQuery = TermQueryFactoryUtil.create(searchContext, Field.ENTRY_CLASS_NAME,Project.class.getName());
        booleanQuery.add(termQuery, BooleanClauseOccur.MUST);
        
        if(categoryId!=0)
        {
        	TermQuery termQuery1 = TermQueryFactoryUtil.create(searchContext, Field.ASSET_CATEGORY_IDS,	categoryId);
        	 booleanQuery.add(termQuery1, BooleanClauseOccur.MUST);  
        }
        
        Sort[] sorts = new Sort[] {};
        
		Hits hits = SearchEngineUtil.search(searchEngineId, companyId, booleanQuery, sorts, 0, 10);
		
		List<ProjectSearch> psList = new ArrayList<ProjectSearch>();
		
		for(int i=0;i<hits.getDocs().length;i++)
		{
			Document doc = hits.doc(i);
			
			String title = doc.get("title");
			String categoryTitle = doc.get("assetCategoryTitles");
			String desc = doc.get("description");
			Long imageId= Long.parseLong(doc.get("content"));
			Long proId = Long.parseLong(doc.get("classPK"));
			
			ProjectSearch ps = new ProjectSearch(proId, title, desc, categoryTitle, imageId);
			psList.add(ps);
		}
		hrequest.setAttribute("projects2", psList);
		
		p1.urlMap(request, response);
		
		response.setRenderParameter("jspPage","/html/projectscategory/showProjectsByCategory.jsp");		
	}
}
