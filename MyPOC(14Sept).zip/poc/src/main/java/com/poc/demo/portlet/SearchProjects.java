package com.poc.demo.portlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.demo.poc.model.Project;
import com.demo.poc.service.ProjectLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.search.BooleanClauseOccur;
import com.liferay.portal.kernel.search.BooleanQuery;
import com.liferay.portal.kernel.search.BooleanQueryFactoryUtil;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.kernel.search.Hits;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.SearchEngineUtil;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.TermQuery;
import com.liferay.portal.kernel.search.TermQueryFactoryUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.poc.demo.helper.ProjectImage;
import com.poc.demo.helper.SearchPojo;

public class SearchProjects {
	ProjectImage projectImage = new ProjectImage();

	public void viewBySearch(ActionRequest request, ActionResponse response, String searchText)
			throws PortalException, SystemException, IOException, PortletException {
		SearchPojo searchPojo = null;
		SearchContext searchContext = SearchContextFactory.getInstance(PortalUtil.getHttpServletRequest(request));
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);

		if (searchText != null && !searchText.isEmpty()) {
			BooleanQuery fullQuery = BooleanQueryFactoryUtil.create(searchContext);
			BooleanQuery classNameQuery = BooleanQueryFactoryUtil.create(searchContext);
			BooleanQuery searchQuery = BooleanQueryFactoryUtil.create(searchContext);

			classNameQuery.addRequiredTerm(Field.ENTRY_CLASS_NAME, Project.class.getName());

			searchQuery.addTerm(Field.ASSET_TAG_NAMES, searchText);
			searchQuery.addTerm(Field.TITLE, searchText);
			searchQuery.addTerm(Field.ASSET_CATEGORY_TITLES, searchText);

			fullQuery.add(classNameQuery, BooleanClauseOccur.MUST);
			fullQuery.add(searchQuery, BooleanClauseOccur.MUST);

			Hits hits = SearchEngineUtil.search(searchContext, fullQuery);

			List<SearchPojo> psList = new ArrayList<SearchPojo>();

			for (int i = 0; i < hits.getDocs().length; i++) {
				Document doc = hits.doc(i);

				Long proId = Long.parseLong(doc.get("classPK"));
				Project project = ProjectLocalServiceUtil.getProject(proId);
				if (project.getProjectStatus() == 0) {

					String title = doc.get("title");
					String categoryTitle = doc.get("assetCategoryTitles");
					String desc = doc.get("description");
					Long imageId = Long.parseLong(doc.get("content"));

					FileEntry fileEntry = DLAppLocalServiceUtil.getFileEntry(imageId);
					String imageURL = themeDisplay.getPortalURL() + themeDisplay.getPathContext() + "/documents/"
							+ themeDisplay.getScopeGroupId() + "/" + fileEntry.getFolderId() + "/"
							+ fileEntry.getTitle();

					searchPojo = new SearchPojo(proId, title, desc, categoryTitle, imageId, imageURL);
				}

				if (searchPojo != null)
					psList.add(searchPojo);
			}

			request.setAttribute("projects", psList);

			response.setRenderParameter("jspPage", "/html/search/showSearchResult.jsp");
		} else {
			System.out.println("Something Went Wrong....");
		}
	}

	public void viewByCategory(RenderRequest renderRequest, RenderResponse renderResponse, long categoryId)
			throws PortalException, SystemException, IOException, PortletException {
		SearchPojo searchPojo = null;
		SearchContext searchContext = SearchContextFactory.getInstance(PortalUtil.getHttpServletRequest(renderRequest));
		String searchEngineId = searchContext.getSearchEngineId();
		Long companyId = searchContext.getCompanyId();

		BooleanQuery booleanQuery = BooleanQueryFactoryUtil.create(searchContext);

		TermQuery termQuery = TermQueryFactoryUtil.create(searchContext, Field.ENTRY_CLASS_NAME,
				Project.class.getName());
		booleanQuery.add(termQuery, BooleanClauseOccur.MUST);

		if (categoryId != 0) {
			TermQuery termQuery1 = TermQueryFactoryUtil.create(searchContext, Field.ASSET_CATEGORY_IDS, categoryId);
			booleanQuery.add(termQuery1, BooleanClauseOccur.MUST);
		}

		Sort[] sorts = new Sort[] {};

		Hits hits = SearchEngineUtil.search(searchEngineId, companyId, booleanQuery, sorts, 0, 10);

		List<SearchPojo> psList = new ArrayList<SearchPojo>();

		for (int i = 0; i < hits.getDocs().length; i++) {
			Document doc = hits.doc(i);

			Long proId = Long.parseLong(doc.get("classPK"));
			Project project = ProjectLocalServiceUtil.getProject(proId);
			if (project.getProjectStatus() == 0) {
				String proTitle = doc.get("title");
				String proCategoryTitle = doc.get("assetCategoryTitles");
				String proDesc = doc.get("description");
				Long proImageId = Long.parseLong(doc.get("content"));
				String proImageLink = StringPool.BLANK;

				Map<Long, String> imageLink = projectImage.urlMap(renderRequest, renderResponse);
				for (Map.Entry<Long, String> linkValue : imageLink.entrySet()) {
					if (proImageId.equals(linkValue.getKey())) {
						proImageLink = linkValue.getValue();
					}
				}

				searchPojo = new SearchPojo(proId, proTitle, proDesc, proCategoryTitle, proImageId, proImageLink);
			}

			if (searchPojo != null)
				psList.add(searchPojo);
		}
		renderRequest.setAttribute("projects", psList);
	}
}
