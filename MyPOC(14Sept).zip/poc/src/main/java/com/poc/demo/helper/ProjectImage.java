package com.poc.demo.helper;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.RoleConstants;
import com.liferay.portal.service.ResourcePermissionServiceUtil;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLAppServiceUtil;
import com.liferay.util.portlet.PortletProps;

public class ProjectImage {
	private static String ROOT_FOLDER_NAME = PortletProps.get("fileupload.folder.name");
	private static String ROOT_FOLDER_DESCRIPTION = PortletProps.get("fileupload.folder.description");
	private static long PARENT_FOLDER_ID = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;

	public long uploadDocument(ActionRequest actionRequest, ActionResponse actionResponse, int projectImageNum)
			throws IOException, PortletException, PortalException, SystemException {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		createFolder(actionRequest, themeDisplay);
		long imgId = fileUpload(themeDisplay, actionRequest, projectImageNum);
		return imgId;
	}

	public Folder createFolder(ActionRequest actionRequest, ThemeDisplay themeDisplay) {
		boolean folderExist = isFolderExist(themeDisplay);
		Folder folder = null;
		if (!folderExist) {
			long repositoryId = themeDisplay.getScopeGroupId();
			long userId = themeDisplay.getUserId();
			ServiceContext serviceContext;
			try {
				serviceContext = ServiceContextFactory.getInstance(DLFolder.class.getName(), actionRequest);
				folder = DLAppLocalServiceUtil.addFolder(userId, repositoryId, PARENT_FOLDER_ID, ROOT_FOLDER_NAME,
						ROOT_FOLDER_DESCRIPTION, serviceContext);
			} catch (PortalException | SystemException e) {
				e.printStackTrace();
			}
		}
		return folder;
	}

	public boolean isFolderExist(ThemeDisplay themeDisplay) {
		boolean folderExist = false;
		try {
			DLAppLocalServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME);
			folderExist = true;
		} catch (PortalException | SystemException e) {
			e.printStackTrace();
		}
		return folderExist;
	}

	public long fileUpload(ThemeDisplay themeDisplay, ActionRequest actionRequest, int proImageNum) {
		long imgid = 0;

		try {
			String projectImgNum = String.format("%04d", proImageNum);

			UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
			String fileName = uploadPortletRequest.getFileName("uploadedFile");
			File file = uploadPortletRequest.getFile("uploadedFile");
			String mimeType = uploadPortletRequest.getContentType("uploadedFile");
			String title = "IMG-" + projectImgNum;
			String description = "This file is added via programatically";

			long repositoryId = themeDisplay.getScopeGroupId();
			long userId = themeDisplay.getUserId();

			Folder folder = getFolder(themeDisplay);
			ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(),
					actionRequest);
			
			FileEntry imgentryId = DLAppLocalServiceUtil.addFileEntry(userId, repositoryId, folder.getFolderId(), fileName, mimeType, title, description, "", file, serviceContext);
			
			

			Map<Long, String[]> roleIdsToActionIdsForFileEntrries = new HashMap<Long, String[]>();
			Role role = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(), RoleConstants.GUEST);
			String[] actionIdsForFileEntry = new String[] { "VIEW" };
			roleIdsToActionIdsForFileEntrries.put(role.getRoleId(), actionIdsForFileEntry);
			setAccessPermissionForGuestUsers(themeDisplay, String.valueOf(folder.getFolderId()),
					"com.liferay.portlet.documentlibrary.model.DLFolder", actionIdsForFileEntry, role);

			String fileEntryId = String.valueOf(imgentryId.getFileEntryId());

			ResourcePermissionServiceUtil.setIndividualResourcePermissions(themeDisplay.getScopeGroupId(),
					themeDisplay.getCompanyId(), "com.liferay.portlet.documentlibrary.model.DLFileEntry", fileEntryId,
					roleIdsToActionIdsForFileEntrries);

			imgid = imgentryId.getFileEntryId();
		} catch (PortalException | SystemException e) {
			System.out.println("Exception occured while save document " + e);
		}
		return imgid;
	}

	public Folder getFolder(ThemeDisplay themeDisplay) {
		Folder folder = null;
		try {
			folder = DLAppServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME);
		} catch (PortalException | SystemException e) {
			e.printStackTrace();
		}
		return folder;
	}

	private void setAccessPermissionForGuestUsers(ThemeDisplay themeDisplay, String entryId, String entryClassName,
			String[] actionIds, Role role) {
		Map<Long, String[]> roleIdsToActionIds = new HashMap<Long, String[]>();
		roleIdsToActionIds.put(role.getRoleId(), actionIds);
		try {
			ResourcePermissionServiceUtil.setIndividualResourcePermissions(themeDisplay.getScopeGroupId(),
					themeDisplay.getCompanyId(), entryClassName, entryId, roleIdsToActionIds);
		} catch (PortalException | SystemException e) {
			e.printStackTrace();
		}
	}

	public void urlMap(ActionRequest actionRequest, ActionResponse actionResponse) {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		Map<String, String> urlMap = getAllFileLink(themeDisplay);
		actionRequest.setAttribute("urlMap", urlMap);
	}

	public Map<Long, String> urlMap(RenderRequest renderRequest, RenderResponse renderResponse) {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		Map<Long, String> urlMap = getAllLink(themeDisplay);
		//renderRequest.setAttribute("urlMap", urlMap);
		return urlMap;
	}

	public void downloadFiles(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException, PortalException, SystemException {
		urlMap(actionRequest, actionResponse);
		actionResponse.setRenderParameter("jspPage", "/html/addprojects/showProjectDetails.jsp");
	}
	
	public Map<String, String> getAllFileLink(ThemeDisplay themeDisplay) {
		Map<String, String> urlMap = new HashMap<String, String>();
		long repositoryId = themeDisplay.getScopeGroupId();

		try {
			Folder folder = getFolder(themeDisplay);
			List<FileEntry> fileEntries;

			fileEntries = DLAppServiceUtil.getFileEntries(repositoryId, folder.getFolderId());

			for (FileEntry file : fileEntries) {
				String url = themeDisplay.getPortalURL() + themeDisplay.getPathContext() + "/documents/"
						+ themeDisplay.getScopeGroupId() + "/" + file.getFolderId() + "/" + file.getTitle();
				urlMap.put(String.valueOf(file.getFileEntryId()), url);
			}
		} catch (PortalException | SystemException e) {
			e.printStackTrace();
		}
		return urlMap;
	}

	public Map<Long, String> getAllLink(ThemeDisplay themeDisplay) {
		Map<Long, String> urlMap = new HashMap<Long, String>();
		long repositoryId = themeDisplay.getScopeGroupId();

		try {
			Folder folder = getFolder(themeDisplay);
			List<FileEntry> fileEntries;

			fileEntries = DLAppServiceUtil.getFileEntries(repositoryId, folder.getFolderId());

			for (FileEntry file : fileEntries) {
				String url = themeDisplay.getPortalURL() + themeDisplay.getPathContext() + "/documents/"
						+ themeDisplay.getScopeGroupId() + "/" + file.getFolderId() + "/" + file.getTitle();
				urlMap.put(file.getFileEntryId(), url);
			}
		} catch (PortalException | SystemException e) {
			e.printStackTrace();
		}
		return urlMap;
	}
}
