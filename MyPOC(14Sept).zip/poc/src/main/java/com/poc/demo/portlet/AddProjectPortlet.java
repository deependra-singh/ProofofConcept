package com.poc.demo.portlet;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.demo.poc.model.Project;
import com.demo.poc.service.ProjectLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.poc.demo.helper.ProjectImage;

/**
 * Portlet implementation class AddProjectPortlet
 */
public class AddProjectPortlet extends MVCPortlet {

	ProjectImage projectImage = new ProjectImage();

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws PortletException, IOException {
		int count;
		try {
			count = AssetCategoryLocalServiceUtil.getAssetCategoriesCount();
			List<AssetCategory> category = AssetCategoryLocalServiceUtil.getAssetCategories(0, count);

			renderRequest.setAttribute("category", category);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		super.render(renderRequest, renderResponse);
	}

	public void addProject(ActionRequest actionRequest, ActionResponse actionResponse) {
		int projectImageNum = 0;
		Project proInfo;
		ServiceContext serviceContext;

		try {
			serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), actionRequest);

			long groupId = serviceContext.getScopeGroupId();
			List<Project> projects = ProjectLocalServiceUtil.getProjects(groupId);

			if (projects.size() == 0)
				projectImageNum = 3;
			else {
				proInfo = projects.get(projects.size() - 1);
				projectImageNum = proInfo.getProjectImageNum() + 1;
			}

			String proTitle = ParamUtil.getString(actionRequest, "proTitle");
			String description = ParamUtil.getString(actionRequest, "description");
			long imageId = projectImage.uploadDocument(actionRequest, actionResponse, projectImageNum);
			long categoryId = ParamUtil.getLong(actionRequest, "Category");

			ProjectLocalServiceUtil.addProject(serviceContext.getUserId(), proTitle, description, imageId, categoryId,
					projectImageNum, serviceContext);
			SessionMessages.add(actionRequest, "ProjectAdded");
			actionResponse.setRenderParameter("mvcPath", "/html/addproject/view.jsp");
		} catch (PortalException | SystemException | IOException | PortletException e) {
			SessionErrors.add(actionRequest, e.getClass().getName());
			actionResponse.setRenderParameter("mvcPath", "/html/addproject/view.jsp");
			e.printStackTrace();
		}
	}

}
