package com.demo.poc.model;

import com.liferay.portal.kernel.util.Accessor;
import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the Project service. Represents a row in the &quot;poc_Project&quot; database table, with each column mapped to a property of this class.
 *
 * @author deependras
 * @see ProjectModel
 * @see com.demo.poc.model.impl.ProjectImpl
 * @see com.demo.poc.model.impl.ProjectModelImpl
 * @generated
 */
public interface Project extends ProjectModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link com.demo.poc.model.impl.ProjectImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
    public static final Accessor<Project, String> UUID_ACCESSOR = new Accessor<Project, String>() {
            @Override
            public String get(Project project) {
                return project.getUuid();
            }
        };
}
