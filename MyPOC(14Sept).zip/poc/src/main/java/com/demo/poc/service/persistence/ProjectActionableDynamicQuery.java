package com.demo.poc.service.persistence;

import com.demo.poc.model.Project;
import com.demo.poc.service.ProjectLocalServiceUtil;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * @author deependras
 * @generated
 */
public abstract class ProjectActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ProjectActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ProjectLocalServiceUtil.getService());
        setClass(Project.class);

        setClassLoader(com.demo.poc.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("projectId");
    }
}
